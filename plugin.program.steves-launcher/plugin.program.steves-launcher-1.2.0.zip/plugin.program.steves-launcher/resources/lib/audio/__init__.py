from abc import ABC, abstractmethod
from dataclasses import dataclass
from functools import cached_property


@dataclass
class SinkInputCriteria:
    app_id: str = ""
    tag: str = ""


class SinkInput(ABC):
    @abstractmethod
    def set_sink(self, sink: str) -> None:
        pass

    @abstractmethod
    def set_volume(self, volume: float) -> None:
        pass


class AudioService(ABC):
    @property
    @abstractmethod
    def id(self) -> str:
        pass

    @cached_property
    @abstractmethod
    def is_available(self) -> bool:
        pass

    @abstractmethod
    def find_sink_input(self, criteria: SinkInputCriteria) -> SinkInput | None:
        pass
