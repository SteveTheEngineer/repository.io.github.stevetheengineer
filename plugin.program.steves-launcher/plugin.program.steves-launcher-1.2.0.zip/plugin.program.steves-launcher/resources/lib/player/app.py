import json
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib.app import App
from resources.lib.player import StaticExternalPlayer
from resources.lib.util.input_capture import InputCapture
from resources.lib.util.kodi_audio import (
    get_audio_sink,
    get_audio_volume,
    is_audio_muted,
)


class _AppMonitor(xbmc.Monitor):
    def onNotification(self, sender: str, method: str, data: str) -> None:
        if sender == "xbmc" and method == "Application.OnVolumeChanged":
            body = json.loads(data)

            is_muted = bool(body["muted"])
            volume = float(body["volume"]) / 100.0

            self.on_volume(volume if not is_muted else 0.0)

    def on_volume(self, volume: float) -> None:
        pass


class AppPlayer(StaticExternalPlayer):
    def __init__(self, addon: xbmcaddon.Addon, app: App) -> None:
        super().__init__(addon)

        self._addon = addon

        self._app = app
        self._instance = self._app.create_instance()

        self._capture = InputCapture()
        self._capture.on_action = self._on_action

        self._sync_audio = self._instance.is_audio_available

    def _poll_process(self) -> bool:
        if self._instance.poll() is not None:
            self.stop()
            return False

        if self._sync_audio and self._instance.is_audio_initialized:
            sink = get_audio_sink()

            if sink is not None:
                self._instance.set_audio_sink(sink)

            xbmc.log(f"muted = {is_audio_muted()}", xbmc.LOGINFO)

            self._instance.set_audio_volume(
                get_audio_volume() if not is_audio_muted() else 0.0
            )

            self._sync_audio = False

        time.sleep(0.1)

        return True

    def _poll_process_loop(self) -> None:
        while self._poll_process():
            pass

    def _on_action(self, action: xbmcgui.Action) -> None:
        self._instance.send_action(action.getId())

    @property
    def monitor(self) -> xbmc.Monitor:
        monitor = _AppMonitor()

        if self._instance.is_audio_available:
            monitor.on_volume = self._instance.set_audio_volume

        return monitor

    @property
    def list_item(self) -> xbmcgui.ListItem:
        return self._app.create_list_item(self._addon)

    def on_start(self) -> None:
        self._instance.start()
        threading.Thread(target=self._poll_process_loop, daemon=True).start()

        self._capture.start()

    def on_stop(self) -> None:
        self._capture.stop()
        self._instance.stop()
