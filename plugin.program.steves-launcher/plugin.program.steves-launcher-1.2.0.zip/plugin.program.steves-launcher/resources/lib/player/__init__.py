from enum import Enum
from re import S
from typing import Any

import xbmc
import xbmcaddon
import xbmcgui


class PlayerState(Enum):
    STOPPED = 0
    SHOULD_START = 1
    STARTED = 2


class StaticExternalPlayer(xbmc.Player):
    def __init__(self, addon: xbmcaddon.Addon) -> None:
        super().__init__()

        self._dummy_video_path = addon.getAddonInfo("path") + "/resources/blank.mp4"
        self._state = PlayerState.STOPPED

    def _reset(self, is_paused: bool | None = None) -> None:
        if not (is_paused or xbmc.getCondVisibility("Player.Paused")):
            self.pause()

        try:
            self.seekTime(0)
        except RuntimeError as err:
            xbmc.log(f"Failed to seek external player: {err}", xbmc.LOGWARNING)

    def do_start(self) -> None:
        if self._state == PlayerState.STOPPED:
            return

        if self._state == PlayerState.STARTED:
            self.do_stop()

        if self._state != PlayerState.SHOULD_START:
            return

        self._reset()

        self._state = PlayerState.STARTED
        self.on_start()

    def do_stop(self) -> None:
        if self._state != PlayerState.STARTED:
            self._state = PlayerState.STOPPED
            return

        self._state = PlayerState.STOPPED
        self.on_stop()

    def onPlayBackStarted(self) -> None:
        self.do_start()

    def onPlayBackResumed(self) -> None:
        if self._state != PlayerState.STARTED:
            return

        self._reset(is_paused=False)

    def onPlayBackSeek(self, time: int, seekOffset: int) -> None:
        if time == 0:
            return

        if self._state != PlayerState.STARTED:
            return

        self._reset()

    def onPlayBackStopped(self) -> None:
        if self._state != PlayerState.STARTED:
            return

        self.do_stop()

    @property
    def monitor(self) -> xbmc.Monitor:
        return xbmc.Monitor()

    @property
    def list_item(self) -> xbmcgui.ListItem:
        return xbmcgui.ListItem("External Player")

    def on_start(self) -> None:
        pass

    def on_stop(self) -> None:
        pass

    def play(
        self,
        item: str | xbmc.PlayList = "",
        listitem: Any | None = None,
        windowed: bool = False,
        startpos: int = -1,
    ) -> None:
        self._state = PlayerState.SHOULD_START
        super().play(item, listitem, windowed, startpos)

    def stop(self) -> None:
        super().stop()
        self.on_stop()

    def play_and_wait(self) -> None:
        self.stop()
        self.play(item=self._dummy_video_path, listitem=self.list_item)

        monitor = self.monitor

        while not monitor.abortRequested():
            if monitor.waitForAbort(1):
                break

            if not self.isPlaying() or self._state != PlayerState.STARTED:
                break

        self.stop()
