import sys
import urllib
import urllib.parse

import xbmcaddon

from resources.lib.addon_gen import AppShortcutManager
from resources.lib.pages.context import RequestContext
from resources.lib.pages.registry import get_page
from resources.lib.registry.app import AppRegistry
from resources.lib.util.locale import AppLocale
from resources.lib.util.settings import AppSettings


def main():
    addon = xbmcaddon.Addon()

    handle = int(sys.argv[1])
    base_url = sys.argv[0]
    query = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

    settings = AppSettings(addon.getSettings())
    registry = AppRegistry(settings)
    shortcuts = AppShortcutManager(addon, registry)
    locale = AppLocale(addon)

    context = RequestContext(
        handle=handle,
        base_url=base_url,
        addon=addon,
        settings=settings,
        registry=registry,
        shortcuts=shortcuts,
        locale=locale,
    )

    page = get_page(context, query)

    if page is None:
        msg = "Invalid action name"
        raise RuntimeError(msg)

    page.submit_request(context)


if __name__ == "__main__":
    main()
