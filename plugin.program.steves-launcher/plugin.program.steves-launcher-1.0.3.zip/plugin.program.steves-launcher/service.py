import xbmc
import xbmcaddon

from resources.lib.addon_gen import AppShortcutManager
from resources.lib.registry.app import AppRegistry
from resources.lib.util.settings import AppSettings


class SettingsChangeMonitor(xbmc.Monitor):
    def __init__(self, settings: AppSettings, shortcuts: AppShortcutManager) -> None:
        super().__init__()

        self._settings = settings
        self._shortcuts = shortcuts

    def onSettingsChanged(self) -> None:
        if self._settings.enable_dynamic_addons:
            self._shortcuts.recreate_all()
        else:
            self._shortcuts.clear()

        xbmc.executebuiltin("UpdateLocalAddons")


def main():
    addon = xbmcaddon.Addon()

    settings = AppSettings(addon.getSettings())
    registry = AppRegistry(settings)
    shortcuts = AppShortcutManager(addon, registry)

    settings.update_flags(registry)

    if settings.enable_dynamic_addons:
        shortcuts.recreate_all()
    else:
        shortcuts.clear()

    xbmc.executebuiltin("UpdateLocalAddons")

    monitor = SettingsChangeMonitor(settings, shortcuts)

    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break


if __name__ == "__main__":
    main()
