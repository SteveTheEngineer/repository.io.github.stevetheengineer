import pathlib
import shutil

import xbmc
import xbmcaddon
import xbmcvfs

from resources.lib.app import App
from resources.lib.registry import Registry


class AppShortcutManager:
    def __init__(self, addon: xbmcaddon.Addon, registry: Registry) -> None:
        self._addon = addon
        self._prefix = f"{addon.getAddonInfo('id')}.shortcut"
        self._registry = registry

    def _get_addons_dir(self) -> pathlib.Path:
        addons_dir = xbmcvfs.translatePath("special://home/addons")
        return pathlib.Path(addons_dir)
    
    def _get_addon_id(self, app: App) -> str:
        return f"{self._prefix}.{app.provider_id}.{app.id}"

    def clear(self):
        for entry in self._get_addons_dir().iterdir():
            if entry.name.startswith(f"{self._prefix}."):
                shutil.rmtree(entry)

    def create(self, app: App):
        from resources.lib.pages.actions.launch import LaunchAction

        provider = self._registry.get_app_provider(app.provider_id)

        if provider is None:
            msg = f"Invalid app provider ID for app {app.id}: {app.provider_id}"
            raise RuntimeError(msg)

        addon_id = self._get_addon_id(app)

        target_dir = self._get_addons_dir() / addon_id
        target_dir.mkdir()

        resources_dir = target_dir / "resources"
        resources_dir.mkdir()

        icon_file = resources_dir / "icon"
        app.save_icon_to(icon_file)

        addon_xml_file = target_dir / "addon.xml"
        addon_xml_file.write_text(
            f"""
            <?xml version="1.0" encoding="utf-8" standalone="yes"?>
            <addon xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                xsi:noNamespaceSchemaLocation="metadata.xsd" id="{addon_id}"
                name="{app.name}" version="{app.version}" provider-name="{
                self._addon.getAddonInfo("name")
            }"
            >
                <requires>
                    <import addon="{self._addon.getAddonInfo("id")}" version="{
                self._addon.getAddonInfo("version")
            }" />
                </requires>

                <extension point="xbmc.addon.metadata">
                    <platform>all</platform>

                    <summary>{app.description}</summary>

                    {
                '''
                    <assets>
                        <icon>resources/icon</icon>
                    </assets>
                    '''
                if icon_file.is_file()
                else ""
            }
                </extension>

                <extension point="xbmc.python.script" library="default.py">
                    <provides>executable</provides>
                </extension>
            </addon>
        """.strip()
        )

        launch = LaunchAction(provider, [app])
        base_url = f"plugin://{self._addon.getAddonInfo('id')}/"

        default_script_file = target_dir / "default.py"
        default_script_file.write_text(
            f'import xbmc; xbmc.executebuiltin("RunPlugin({launch.get_url(base_url)})")'
        )

    def enable_addon(self, app: App) -> None:
        xbmc.executebuiltin(f"EnableAddon({self._get_addon_id(app)})")

    def recreate_all(self):
        self.clear()

        for app in self._registry.apps:
            self.create(app)
