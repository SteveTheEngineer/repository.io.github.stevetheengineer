import pathlib
from abc import ABC, abstractmethod
from collections.abc import Sequence
import shutil
import subprocess
from typing import Self

import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.app.instance import AppInstance
from resources.lib.process import PendingProcess
from resources.lib.process.error import ErrorProcess


_RESVG_CMD = "resvg"


class App(ABC):
    @property
    @abstractmethod
    def id(self) -> str:
        pass

    @property
    @abstractmethod
    def provider_id(self) -> str:
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        pass

    @property
    @abstractmethod
    def version(self) -> str:
        pass

    @property
    @abstractmethod
    def icon_path(self) -> pathlib.Path | None:
        pass

    @abstractmethod
    def create_instance(self) -> AppInstance:
        pass

    @property
    def has_children(self) -> bool:
        return False

    @property
    def children(self) -> Sequence[Self]:
        return []

    @property
    def can_uninstall(self) -> bool:
        return False

    def uninstall(self) -> PendingProcess:
        return ErrorProcess("This app does not support uninstalling")

    def save_icon_to(self, target: pathlib.Path) -> None:
        icon = self.icon_path

        if not icon:
            return

        if icon.name.endswith(".svg"):
            if shutil.which(_RESVG_CMD) is None:
                return

            subprocess.run(
                [
                    _RESVG_CMD,
                    "--width",
                    "256",
                    "--height",
                    "256",
                    str(icon),
                    str(target),
                ],
                check=True,
            )
        else:
            icon.copy(target)

    def create_list_item(self, addon: xbmcaddon.Addon) -> xbmcgui.ListItem:
        item = xbmcgui.ListItem(
            label=self.name,
        )

        icon = self.icon_path

        if icon:
            parent_kodi_path = f"special://temp/{addon.getAddonInfo('id')}/icons"
            parent_path = pathlib.Path(xbmcvfs.translatePath(parent_kodi_path))

            parent_path.mkdir(parents=True, exist_ok=True)

            cached_kodi_path = f"{parent_kodi_path}/{self.id}"
            cached_path = pathlib.Path(xbmcvfs.translatePath(cached_kodi_path))

            if not cached_path.is_file():
                self.save_icon_to(cached_path)

            item.setArt(
                {
                    "icon": cached_kodi_path,
                    "thumb": cached_kodi_path,
                }
            )

        return item
