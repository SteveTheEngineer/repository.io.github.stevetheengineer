from abc import ABC
from dataclasses import dataclass


@dataclass
class InstallableApp(ABC):
    id: str
    name: str
    description: str
    version: str
    icon_url: str | None
