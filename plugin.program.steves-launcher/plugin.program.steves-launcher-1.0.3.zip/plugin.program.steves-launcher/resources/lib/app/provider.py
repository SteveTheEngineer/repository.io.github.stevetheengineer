from abc import ABC, abstractmethod
from collections.abc import Sequence

from resources.lib.app import App
from resources.lib.app.installable_app import InstallableApp
from resources.lib.process import PendingProcess
from resources.lib.process.error import ErrorProcess


class AppProvider(ABC):
    @property
    @abstractmethod
    def id(self) -> str:
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        pass

    @property
    @abstractmethod
    def is_available(self) -> bool:
        pass

    @abstractmethod
    def get_all(self) -> Sequence[App]:
        pass

    @abstractmethod
    def get(self, id: str) -> App | None:
        pass

    @property
    def can_install(self) -> bool:
        return False

    def search_installable(self, query: str) -> Sequence[InstallableApp]:
        return []

    def install(self, id: str) -> PendingProcess:
        return ErrorProcess("The provider does not support installations")

    def resolve_path(self, path_str: Sequence[str]) -> Sequence[App] | None:
        path: Sequence[App] = []

        for segment in path_str:
            apps = path[-1].children if len(path) > 0 else self.get_all()

            app = next((x for x in apps if x.id == segment), None)

            if app is None:
                return None

            path = [*path, app]

        return path
