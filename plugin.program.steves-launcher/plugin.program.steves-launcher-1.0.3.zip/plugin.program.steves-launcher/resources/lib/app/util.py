import xbmc
import xbmcgui


def report_error(message: str) -> None:
    xbmc.log(message, xbmc.LOGERROR)

    xbmcgui.Dialog().notification(
        heading="Error", message=message, icon=xbmcgui.NOTIFICATION_ERROR
    )
