from abc import ABC, abstractmethod


class AppInstance(ABC):
    @abstractmethod
    def start(self) -> None:
        pass

    @abstractmethod
    def stop(self) -> None:
        pass

    @abstractmethod
    def poll(self) -> int | None:
        pass

    @abstractmethod
    def send_action(self, action: int) -> None:
        pass

    @property
    @abstractmethod
    def is_audio_available(self) -> bool:
        pass

    @property
    @abstractmethod
    def is_audio_initialized(self) -> bool:
        pass

    @abstractmethod
    def set_audio_sink(self, sink: str) -> None:
        pass

    @abstractmethod
    def set_audio_volume(self, volume: float) -> None:
        pass
