from abc import ABC, abstractmethod
from functools import cached_property


class SinkInput(ABC):
    @abstractmethod
    def set_sink(self, sink: str) -> None:
        pass

    @abstractmethod
    def set_volume(self, volume: float) -> None:
        pass


class AudioService(ABC):
    @property
    @abstractmethod
    def id(self) -> str:
        pass

    @cached_property
    @abstractmethod
    def is_available(self) -> bool:
        pass

    @abstractmethod
    def get_flatpak_sink_input(self, app_id: str) -> SinkInput | None:
        pass
