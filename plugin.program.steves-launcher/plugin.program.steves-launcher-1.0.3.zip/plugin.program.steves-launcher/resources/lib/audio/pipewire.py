import json
import shutil
import subprocess
from functools import cached_property
from typing import Any, override

from resources.lib.app.util import report_error
from resources.lib.audio import AudioService, SinkInput

_PULSE_CMD = "pactl"


class PipeWireSinkInput(SinkInput):
    def __init__(self, id: int) -> None:
        super().__init__()

        self._id = id

    @override
    def set_sink(self, sink: str) -> None:
        subprocess.run([_PULSE_CMD, "move-sink-input", str(self._id), sink], check=True)

    @override
    def set_volume(self, volume: float) -> None:
        subprocess.run(
            [
                _PULSE_CMD,
                "set-sink-input-volume",
                str(self._id),
                f"{volume * 100.0}%",
            ],
            check=True,
        )


class PipeWireAudioService(AudioService):
    @property
    def id(self) -> str:
        return "pipewire"

    @cached_property
    @override
    def is_available(self) -> bool:
        if shutil.which(_PULSE_CMD) is None:
            return False

        try:
            out = subprocess.check_output([_PULSE_CMD, "--format=json", "info"])
        except subprocess.CalledProcessError:
            return False

        data = json.loads(out)

        return "PipeWire" in data.get("server_name", "")

    def _get_sink_inputs(self) -> Any:
        raw = subprocess.check_output(
            [_PULSE_CMD, "--format=json", "list", "sink-inputs"]
        )

        body = json.loads(raw)

        return body

    @override
    def get_flatpak_sink_input(self, app_id: str) -> SinkInput | None:
        if not self.is_available:
            return None

        for input in self._get_sink_inputs():
            props = input.get("properties", {})
            input_app_id = props.get("pipewire.access.portal.app_id", "")

            if input_app_id != app_id:
                continue

            index = input.get("index", None)

            if index is None:
                report_error(f"Sink input ${input} does not have an index")
                return None

            return PipeWireSinkInput(index)
