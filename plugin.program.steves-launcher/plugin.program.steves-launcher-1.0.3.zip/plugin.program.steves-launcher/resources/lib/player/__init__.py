import xbmc
import xbmcaddon
import xbmcgui


class StaticExternalPlayer(xbmc.Player):
    def __init__(self, addon: xbmcaddon.Addon) -> None:
        super().__init__()

        self._dummy_video_path = addon.getAddonInfo("path") + "/resources/blank.mp4"

    def _reset(self) -> None:
        self.pause()
        self.seekTime(0)

    def onPlayBackStarted(self) -> None:
        self._reset()

        self.on_play()

    def onPlayBackResumed(self) -> None:
        self._reset()

    def onPlayBackSeek(self, time: int, seekOffset: int) -> None:
        if time == 0 or not self.isPlaying():
            return

        self.seekTime(0)

    def onPlayBackStopped(self) -> None:
        self.on_stop()

    @property
    def monitor(self) -> xbmc.Monitor:
        return xbmc.Monitor()

    @property
    def list_item(self) -> xbmcgui.ListItem:
        return xbmcgui.ListItem("External Player")

    def on_play(self) -> None:
        pass

    def on_stop(self) -> None:
        pass

    def play_and_wait(self) -> None:
        self.play(item=self._dummy_video_path, listitem=self.list_item)

        monitor = self.monitor

        while not monitor.abortRequested():
            if monitor.waitForAbort(1):
                break

            if not self.isPlaying():
                break
