import json
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Self, override

import xbmcgui

from resources.lib.app import App
from resources.lib.app.provider import AppProvider
from resources.lib.pages.actions.launch import LaunchAction
from resources.lib.pages.actions.start_discover import StartDiscoverAction
from resources.lib.pages.actions.uninstall import UninstallAction
from resources.lib.pages.args import RequestArgs
from resources.lib.pages.context import RequestContext
from resources.lib.pages.dir import DirectoryPage
from resources.lib.pages.dir_entry import DirectoryEntry


@dataclass
class BrowsePage(DirectoryPage):
    provider: AppProvider | None = None
    path: Sequence[App] = field(default_factory=list)

    @classmethod
    @override
    def action_id(cls) -> str:
        return "browse"

    @classmethod
    @override
    def from_args(cls, context: RequestContext, args: RequestArgs) -> Self:
        provider = args.get_provider(context.registry)
        path = args.require_path(provider) if provider else []

        return cls(provider=provider, path=path)

    @override
    def to_args(self) -> dict[str, str | None]:
        return {
            "provider": self.provider.id if self.provider else None,
            "path": json.dumps([x.id for x in self.path]),
        }

    def _entry_for_app(self, context: RequestContext, app: App) -> DirectoryEntry:
        provider = context.registry.get_app_provider(app.provider_id)

        if provider is None:
            msg = f"App does not have an associated provider ID: {app.id}"
            raise RuntimeError(msg)

        path = [*self.path, app]
        item = app.create_list_item(context.addon)
        launch = LaunchAction(provider, path)

        if app.has_children:
            item.addContextMenuItems(
                [
                    (
                        context.locale.action_launch.get(),
                        launch.as_kodi(context.base_url),
                    )
                ]
            )

            return DirectoryEntry(item, BrowsePage(self.provider, path))

        if context.settings.enable_installation and len(path) == 1:
            item.addContextMenuItems(
                [
                    (
                        context.locale.action_uninstall.get(),
                        UninstallAction(provider, path).as_kodi(context.base_url),
                    )
                ]
            )

        return DirectoryEntry(item, launch)

    @override
    def handle(self, context: RequestContext) -> Sequence[DirectoryEntry]:
        entries: list[DirectoryEntry] = []

        apps = (
            (self.path[-1].children if len(self.path) > 0 else self.provider.get_all())
            if self.provider is not None
            else context.registry.apps
        )

        for app in apps:
            entries.append(self._entry_for_app(context, app))

        if (
            context.settings.enable_installation
            and len(self.path) == 0
            and self.provider is not None
        ):
            item = xbmcgui.ListItem(context.locale.action_discover.get())

            item.setArt(
                {
                    "icon": context.resource("add.png"),
                    "thumb": context.resource("add.png"),
                }
            )

            entries.append(
                DirectoryEntry(
                    item,
                    StartDiscoverAction(self.provider),
                )
            )

        return entries
