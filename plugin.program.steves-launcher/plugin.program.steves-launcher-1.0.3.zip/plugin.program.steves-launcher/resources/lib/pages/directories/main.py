from collections.abc import Sequence
from dataclasses import dataclass
from typing import override

import xbmcgui

from resources.lib.pages.context import RequestContext
from resources.lib.pages.dir import DirectoryPage
from resources.lib.pages.dir_entry import DirectoryEntry
from resources.lib.pages.directories.browse import BrowsePage


@dataclass
class MainPage(DirectoryPage):
    @classmethod
    @override
    def action_id(cls) -> str:
        return "main"
    
    @override
    def handle(self, context: RequestContext) -> Sequence[DirectoryEntry]:
        entries: list[DirectoryEntry] = []

        entries.append(
            DirectoryEntry(
                xbmcgui.ListItem(context.locale.action_browse_all.get()), BrowsePage()
            )
        )

        for provider in context.registry.app_providers:
            entries.append(
                DirectoryEntry(
                    xbmcgui.ListItem(provider.name),
                    BrowsePage(provider),
                )
            )

        return entries
