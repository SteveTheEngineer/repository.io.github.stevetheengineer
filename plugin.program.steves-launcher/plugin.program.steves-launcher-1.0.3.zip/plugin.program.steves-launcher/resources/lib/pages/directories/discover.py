from collections.abc import Sequence
from dataclasses import dataclass
from typing import Self, override

import xbmc
import xbmcgui

from resources.lib.app.installable_app import InstallableApp
from resources.lib.app.provider import AppProvider
from resources.lib.pages.actions.install import InstallAction
from resources.lib.pages.args import RequestArgs
from resources.lib.pages.context import RequestContext
from resources.lib.pages.dir import DirectoryPage
from resources.lib.pages.dir_entry import DirectoryEntry


@dataclass
class DiscoverPage(DirectoryPage):
    provider: AppProvider
    query: str

    @classmethod
    @override
    def action_id(cls) -> str:
        return "discover"

    @classmethod
    @override
    def from_args(cls, context: RequestContext, args: RequestArgs) -> Self:
        provider = args.require_provider(context.registry)
        query = args.require_str("query")

        return cls(
            provider=provider,
            query=query,
        )

    @override
    def to_args(self) -> dict[str, str | None]:
        return {"provider": self.provider.id, "query": self.query}

    def _entry_for_result(self, entry: InstallableApp) -> DirectoryEntry:
        return DirectoryEntry(
            page=InstallAction(provider=self.provider, id=entry.id, name=entry.name),
            list_item=xbmcgui.ListItem(f"{entry.name}: {entry.description}"),
        )

    @override
    def handle(self, context: RequestContext) -> Sequence[DirectoryEntry]:
        xbmc.executebuiltin("ActivateWindow(busydialognocancel)")

        try:
            results = self.provider.search_installable(self.query)
        finally:
            xbmc.executebuiltin("Dialog.Close(busydialognocancel)")

        entries: list[DirectoryEntry] = []

        for result in results:
            entries.append(self._entry_for_result(result))

        return entries
