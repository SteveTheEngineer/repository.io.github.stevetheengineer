from dataclasses import dataclass

import xbmcgui

from resources.lib.pages import Page


@dataclass
class DirectoryEntry:
    list_item: xbmcgui.ListItem
    page: Page
