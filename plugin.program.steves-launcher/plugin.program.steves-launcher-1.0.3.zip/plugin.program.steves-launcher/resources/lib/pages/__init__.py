import urllib
import urllib.parse
from abc import ABC, abstractmethod
from typing import Self

from resources.lib.pages.args import RequestArgs
from resources.lib.pages.context import RequestContext


class Page(ABC):
    @classmethod
    @abstractmethod
    def action_id(cls) -> str:
        pass

    @classmethod
    def from_args(cls, context: RequestContext, args: RequestArgs) -> Self:
        return cls()

    def to_args(self) -> dict[str, str | None]:
        return {}

    def get_query_component(self) -> str:
        query = self.to_args()

        query["action"] = self.action_id()

        for key, value in list(query.items()):
            if value is None:
                del query[key]

        return urllib.parse.urlencode(query)

    @property
    @abstractmethod
    def is_folder(self) -> bool:
        pass

    @abstractmethod
    def submit_request(self, context: RequestContext) -> None:
        pass

    def get_url(self, base_url: str) -> str:
        return f"{base_url}?{self.get_query_component()}"
