from abc import abstractmethod
from collections.abc import Sequence
from typing import override

import xbmcplugin

from resources.lib.pages import Page
from resources.lib.pages.context import RequestContext
from resources.lib.pages.dir_entry import DirectoryEntry


class DirectoryPage(Page):
    @abstractmethod
    def handle(self, context: RequestContext) -> Sequence[DirectoryEntry]:
        pass

    @property
    @override
    def is_folder(self):
        return True

    @override
    def submit_request(self, context: RequestContext) -> None:
        entries = self.handle(context)

        for entry in entries:
            xbmcplugin.addDirectoryItem(
                handle=context.handle,
                url=entry.page.get_url(context.base_url),
                listitem=entry.list_item,
                isFolder=entry.page.is_folder,
            )

        xbmcplugin.endOfDirectory(handle=context.handle, cacheToDisc=False)
