import json
from collections.abc import Sequence

from resources.lib.app import App
from resources.lib.app.provider import AppProvider
from resources.lib.registry import Registry


class RequestArgs:
    def __init__(self, args: dict[str, str]) -> None:
        self._args = args

    def get_str(self, key: str) -> str | None:
        return self._args.get(key)

    def require_str(self, key: str) -> str:
        value = self.get_str(key)

        if not value:
            msg = f"Required argument missing: {id}"
            raise RuntimeError(msg)

        return value

    def get_provider(self, registry: Registry) -> AppProvider | None:
        provider_id = self.get_str("provider")

        if provider_id is None:
            return

        provider = registry.get_app_provider(provider_id)

        if provider is None:
            msg = f"Invalid provider ID: {provider_id}"
            raise RuntimeError(msg)

        return provider

    def require_provider(self, registry: Registry) -> AppProvider:
        provider = self.get_provider(registry)

        if provider is None:
            msg = "Required argument missing: provider"
            raise RuntimeError(msg)

        return provider

    def require_path(self, provider: AppProvider) -> Sequence[App]:
        path_str: Sequence[str] = json.loads(self.get_str("path") or "[]")
        return provider.resolve_path(path_str) or []
