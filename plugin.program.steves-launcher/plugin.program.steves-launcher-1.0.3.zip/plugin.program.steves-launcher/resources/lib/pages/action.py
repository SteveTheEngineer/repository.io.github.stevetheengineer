from abc import ABC, abstractmethod
from typing import override

from resources.lib.pages import Page
from resources.lib.pages.context import RequestContext


class ActionPage(Page, ABC):
    @abstractmethod
    def handle(self, context: RequestContext) -> None:
        pass

    @property
    @override
    def is_folder(self) -> bool:
        return False

    @override
    def submit_request(self, context: RequestContext) -> None:
        self.handle(context)

    def as_kodi(self, base_url: str) -> str:
        return f"RunPlugin({self.get_url(base_url)})"