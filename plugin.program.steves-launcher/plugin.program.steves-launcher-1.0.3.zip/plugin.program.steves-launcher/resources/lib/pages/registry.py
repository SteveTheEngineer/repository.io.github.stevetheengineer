from collections.abc import Sequence

from resources.lib.pages import Page
from resources.lib.pages.actions.install import InstallAction
from resources.lib.pages.actions.launch import LaunchAction
from resources.lib.pages.actions.start_discover import StartDiscoverAction
from resources.lib.pages.actions.uninstall import UninstallAction
from resources.lib.pages.args import RequestArgs
from resources.lib.pages.context import RequestContext
from resources.lib.pages.directories.browse import BrowsePage
from resources.lib.pages.directories.discover import DiscoverPage
from resources.lib.pages.directories.main import MainPage

_ALL_PAGES: Sequence[type[Page]] = [
    MainPage,
    BrowsePage,
    DiscoverPage,
    InstallAction,
    LaunchAction,
    UninstallAction,
    StartDiscoverAction,
]


def get_page(context: RequestContext, query: dict[str, str]) -> Page | None:
    action = query.pop("action", MainPage.action_id())

    page_type = next((x for x in _ALL_PAGES if x.action_id() == action), None)

    if page_type is None:
        return None

    args = RequestArgs(query)

    return page_type.from_args(context, args)
