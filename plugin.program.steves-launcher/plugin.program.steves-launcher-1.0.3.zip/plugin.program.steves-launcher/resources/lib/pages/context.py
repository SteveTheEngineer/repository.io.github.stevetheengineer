import pathlib
from dataclasses import dataclass
from typing import TYPE_CHECKING

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib.addon_gen import AppShortcutManager
from resources.lib.process import PendingProcess
from resources.lib.registry import Registry
from resources.lib.util.locale import AppLocale
from resources.lib.util.settings import AppSettings

if TYPE_CHECKING:
    from resources.lib.pages import Page


@dataclass
class RequestContext:
    handle: int
    base_url: str
    addon: xbmcaddon.Addon
    settings: AppSettings
    registry: Registry
    shortcuts: AppShortcutManager
    locale: AppLocale

    def resource(self, path: str) -> str:
        resource_path = (
            pathlib.Path(self.addon.getAddonInfo("path"))
            .joinpath("resources")
            .joinpath(path)
        )
        return str(resource_path)

    def navigate(self, target: "Page") -> None:
        xbmc.executebuiltin(f"Container.Update({target.get_url(self.base_url)})")

    def report_error(self, message: str) -> None:
        xbmc.log(message, xbmc.LOGERROR)

        xbmcgui.Dialog().notification(
            heading="Error", message=message, icon=xbmcgui.NOTIFICATION_ERROR
        )

    def wait_for_process(self, process: PendingProcess, label: str) -> None:
        progress = xbmcgui.DialogProgress()
        progress.create(label, process.status)

        monitor = xbmc.Monitor()

        while not monitor.abortRequested():
            progress.update(int(100.0 * process.progress), process.status)

            if not process.is_active or progress.iscanceled():
                break

            if monitor.waitForAbort(0.1):
                break

        if process.is_error:
            self.report_error(process.status)

            process.cancel()
            progress.close()

    def app_list_updated(self) -> None:
        if self.settings.enable_dynamic_addons:
            self.shortcuts.recreate_all()
            xbmc.executebuiltin("UpdateLocalAddons")
