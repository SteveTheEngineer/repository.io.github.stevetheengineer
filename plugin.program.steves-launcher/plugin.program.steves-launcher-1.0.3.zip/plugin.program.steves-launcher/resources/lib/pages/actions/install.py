from dataclasses import dataclass
from typing import Self, override

import xbmcgui

from resources.lib.app.provider import AppProvider
from resources.lib.pages.action import ActionPage
from resources.lib.pages.args import RequestArgs
from resources.lib.pages.context import RequestContext


@dataclass
class InstallAction(ActionPage):
    provider: AppProvider
    id: str
    name: str

    @classmethod
    @override
    def action_id(cls) -> str:
        return "install"

    @classmethod
    @override
    def from_args(cls, context: RequestContext, args: RequestArgs) -> Self:
        provider = args.require_provider(context.registry)
        id = args.require_str("id")
        name = args.require_str("name")

        return cls(provider=provider, id=id, name=name)

    @override
    def to_args(self) -> dict[str, str | None]:
        return {"provider": self.provider.id, "id": self.id, "name": self.name}

    @override
    def handle(self, context: RequestContext) -> None:
        if not context.settings.enable_installation:
            msg = "App management is not enabled"
            raise RuntimeError(msg)

        if self.provider.get(self.id) is not None:
            xbmcgui.Dialog().ok(
                context.locale.dialog_already_installed_title.get(),
                context.locale.dialog_already_installed_content.get(
                    app_name=self.name
                ),
            )

            return

        if not xbmcgui.Dialog().yesno(
            context.locale.confirm_install_title.get(),
            context.locale.confirm_install_content.get(app_name=self.name),
        ):
            return

        process = self.provider.install(self.id)
        context.wait_for_process(
            process, context.locale.confirm_install_content.get(app_name=self.name)
        )

        context.app_list_updated()

        app = self.provider.get(self.id)

        if context.settings.enable_dynamic_addons and app is not None:
            context.shortcuts.enable_addon(app)
