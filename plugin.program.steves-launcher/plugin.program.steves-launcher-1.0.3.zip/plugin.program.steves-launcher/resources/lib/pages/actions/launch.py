import json
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Self, override

import xbmc

from resources.lib.app import App
from resources.lib.app.provider import AppProvider
from resources.lib.pages.action import ActionPage
from resources.lib.pages.args import RequestArgs
from resources.lib.pages.context import RequestContext
from resources.lib.player.app import AppPlayer


@dataclass
class LaunchAction(ActionPage):
    provider: AppProvider
    path: Sequence[App] = field(default_factory=list)

    @classmethod
    @override
    def action_id(cls) -> str:
        return "launch"

    @classmethod
    @override
    def from_args(cls, context: RequestContext, args: RequestArgs) -> Self:
        provider = args.require_provider(context.registry)
        path = args.require_path(provider)

        return cls(provider=provider, path=path)

    @override
    def to_args(self) -> dict[str, str | None]:
        return {
            "provider": self.provider.id,
            "path": json.dumps([x.id for x in self.path]),
        }

    @property
    def _app(self) -> App:
        app = self.path[-1] if len(self.path) > 0 else None

        if app is None:
            msg = "Empty path provided"
            raise RuntimeError(msg)

        return app

    @override
    def handle(self, context: RequestContext) -> None:
        app = self._app

        if not context.settings.enable_dummy_player:
            instance = app.create_instance()
            instance.start()
            return

        default_monitor = xbmc.Monitor()
        default_player = xbmc.Player()

        while not default_monitor.abortRequested() and default_player.isPlaying():
            default_player.stop()

            if default_monitor.waitForAbort(1):
                return

        player = AppPlayer(context.addon, app)
        player.play_and_wait()
