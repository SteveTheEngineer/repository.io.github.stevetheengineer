import json
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Self, override

import xbmc
import xbmcgui

from resources.lib.app import App
from resources.lib.app.provider import AppProvider
from resources.lib.pages.action import ActionPage
from resources.lib.pages.args import RequestArgs
from resources.lib.pages.context import RequestContext


@dataclass
class UninstallAction(ActionPage):
    provider: AppProvider
    path: Sequence[App] = field(default_factory=list)

    @classmethod
    @override
    def action_id(cls) -> str:
        return "uninstall"

    @classmethod
    @override
    def from_args(cls, context: RequestContext, args: RequestArgs) -> Self:
        provider = args.require_provider(context.registry)
        path = args.require_path(provider)

        return cls(provider=provider, path=path)

    @override
    def to_args(self) -> dict[str, str | None]:
        return {
            "provider": self.provider.id,
            "path": json.dumps([x.id for x in self.path]),
        }

    @property
    def _app(self) -> App:
        app = self.path[-1] if len(self.path) > 0 else None

        if app is None:
            msg = "Empty path provided"
            raise RuntimeError(msg)

        return app

    @override
    def handle(self, context: RequestContext) -> None:
        app = self._app

        if not app.can_uninstall:
            msg = f"App is not uninstallable: {app.name}"
            raise RuntimeError(msg)

        if not xbmcgui.Dialog().yesno(
            context.locale.confirm_uninstall_title.get(),
            context.locale.confirm_uninstall_content.get(app_name=app.name),
        ):
            return

        process = app.uninstall()
        context.wait_for_process(
            process, context.locale.progress_uninstalling.get(app_name=app.name)
        )

        context.app_list_updated()
        xbmc.executebuiltin("Container.Refresh")
