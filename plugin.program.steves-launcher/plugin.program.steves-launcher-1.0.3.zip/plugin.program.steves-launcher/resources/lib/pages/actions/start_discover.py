from dataclasses import dataclass
from typing import Self, override

import xbmcgui

from resources.lib.app.provider import AppProvider
from resources.lib.pages.action import ActionPage
from resources.lib.pages.args import RequestArgs
from resources.lib.pages.context import RequestContext
from resources.lib.pages.directories.discover import DiscoverPage


@dataclass
class StartDiscoverAction(ActionPage):
    provider: AppProvider

    @classmethod
    @override
    def action_id(cls) -> str:
        return "start_discover"

    @classmethod
    @override
    def from_args(cls, context: RequestContext, args: RequestArgs) -> Self:
        provider = args.require_provider(context.registry)

        return cls(provider=provider)

    @override
    def to_args(self) -> dict[str, str | None]:
        return {"provider": self.provider.id}

    @override
    def handle(self, context: RequestContext) -> None:
        query = xbmcgui.Dialog().input(context.locale.dialog_discover_title.get())

        if not query:
            return

        context.navigate(DiscoverPage(self.provider, query))
