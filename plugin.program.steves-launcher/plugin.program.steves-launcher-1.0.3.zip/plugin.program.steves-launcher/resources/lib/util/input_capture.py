import xbmc
import xbmcgui


class InputCapture(xbmcgui.WindowDialog):
    def onAction(self, action: xbmcgui.Action) -> None:
        self.on_action(action)

    def onControl(self, control: xbmcgui.Control) -> None:
        pass

    def start(self) -> None:
        xbmc.enableNavSounds(False)
        self.doModal()

    def stop(self) -> None:
        xbmc.enableNavSounds(True)
        self.close()

    def on_action(self, action: xbmcgui.Action) -> None:
        pass
