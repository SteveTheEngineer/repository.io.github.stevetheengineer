import xbmcaddon

from resources.lib.registry import Registry


class AppSettings:
    def __init__(self, settings: xbmcaddon.Settings) -> None:
        self._raw = settings

    @property
    def enable_dummy_player(self) -> bool:
        return self._raw.getBool("enable_dummy_player")

    @property
    def enable_dynamic_addons(self) -> bool:
        return self._raw.getBool("enable_dynamic_addons")

    @property
    def enable_installation(self) -> bool:
        return self._raw.getBool("enable_installation")

    def is_enabled(self, name: str) -> bool:
        return self._raw.getBool(f"enable_{name}")

    def update_flags(self, registry: Registry) -> None:
        for service in registry.all_audio_services:
            self._raw.setBool(f"flag_{service.id}_available", service.is_available)

        for provider in registry.all_app_providers:
            self._raw.setBool(f"flag_{provider.id}_available", provider.is_available)

        for input in registry.all_virtual_inputs:
            self._raw.setBool(f"flag_{input.id}_available", input.is_available)
