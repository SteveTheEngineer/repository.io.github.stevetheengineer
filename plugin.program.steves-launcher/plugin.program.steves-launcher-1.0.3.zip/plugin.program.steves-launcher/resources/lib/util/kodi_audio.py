import json

import xbmc


def is_audio_muted():
    return xbmc.getCondVisibility("Player.Muted")


def get_audio_volume() -> float:
    raw = xbmc.getInfoLabel("Player.Volume")
    db = float(raw.removesuffix(" dB"))
    return 1.0 - (-db / 60.0)


def get_audio_sink() -> str | None:
    req = {
        "jsonrpc": "2.0",
        "method": "Settings.GetSettingValue",
        "params": {"setting": "audiooutput.audiodevice"},
        "id": 1,
    }

    res = xbmc.executeJSONRPC(json.dumps(req))
    body = json.loads(res)

    if "result" not in body:
        return None

    value: str = body["result"]["value"]
    parts: list[str] = []

    if value.startswith("PULSE:"):
        parts = value.removeprefix("PULSE:").split("|")
    elif value.startswith("PIPEWIRE:"):
        parts = value.removeprefix("PIPEWIRE:").split("|")
    else:
        return None

    name = parts[0]

    if name == "Default":
        return "@DEFAULT_SINK@"

    return name
