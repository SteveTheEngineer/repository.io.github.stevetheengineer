from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import xbmcaddon


@dataclass()
class AppLocaleString:
    addon: "xbmcaddon.Addon | None"
    id: int
    value: str

    def get(self, **kwargs: str):
        if self.addon is None:
            return self.value.format(**kwargs)

        return self.addon.getLocalizedString(self.id).format(**kwargs)


class AppLocale:
    def __init__(self, addon: "xbmcaddon.Addon | None") -> None:
        self.settings_general = AppLocaleString(addon, 30000, "General")

        self.settings_integrations = AppLocaleString(addon, 30011, "Integrations")
        self.settings_media_player = AppLocaleString(addon, 30008, "Media player")
        self.settings_dynamic_addons = AppLocaleString(
            addon, 30009, "Register applications as addons"
        )
        self.settings_allow_installations = AppLocaleString(
            addon, 30025, "Allow managing app installations"
        )

        self.settings_audio = AppLocaleString(addon, 30007, "Audio")
        self.settings_pipewire = AppLocaleString(addon, 30010, "PipeWire")

        self.settings_sources = AppLocaleString(addon, 30001, "Sources")
        self.settings_flatpak = AppLocaleString(addon, 30002, "Flatpak")

        self.settings_input = AppLocaleString(addon, 30003, "Input")
        self.settings_dotool = AppLocaleString(addon, 30004, "dotool")
        self.settings_ydotool = AppLocaleString(addon, 30005, "ydotool")
        self.settings_xdotool = AppLocaleString(addon, 30006, "xdotool")

        self.action_browse_all = AppLocaleString(addon, 30012, "All")
        self.action_launch = AppLocaleString(addon, 30013, "Launch")
        self.action_uninstall = AppLocaleString(addon, 30014, "Uninstall")
        self.action_discover = AppLocaleString(addon, 30015, "Get more applications...")

        self.confirm_uninstall_title = AppLocaleString(
            addon, 30016, "Uninstall Application"
        )
        self.confirm_uninstall_content = AppLocaleString(
            addon, 30017, "Uninstall {app_name}?"
        )

        self.dialog_discover_title = AppLocaleString(addon, 30018, "Search query:")

        self.dialog_already_installed_title = AppLocaleString(
            addon, 30019, "Already installed"
        )
        self.dialog_already_installed_content = AppLocaleString(
            addon, 30020, "The app {app_name} is already installed"
        )

        self.confirm_install_title = AppLocaleString(
            addon, 30021, "Install Application"
        )
        self.confirm_install_content = AppLocaleString(
            addon, 30022, "Install {app_name}?"
        )

        self.progress_installing = AppLocaleString(
            addon, 30023, "Installing {app_name}..."
        )
        self.progress_uninstalling = AppLocaleString(
            addon, 30024, "Uninstalling {app_name}..."
        )

    def all(self) -> Sequence[AppLocaleString]:
        return [x for x in self.__dict__.values() if isinstance(x, AppLocaleString)]
