import shutil
import subprocess
from typing import override

import xbmcgui

from resources.lib.virtual_input import VirtualInput

_DOTOOL_CMD = "dotoolc"
_DOTOOL_ACTION_MAP = {
    xbmcgui.ACTION_MOVE_LEFT: "left",
    xbmcgui.ACTION_MOVE_RIGHT: "right",
    xbmcgui.ACTION_MOVE_UP: "up",
    xbmcgui.ACTION_MOVE_DOWN: "down",
    xbmcgui.ACTION_SELECT_ITEM: "enter",
    xbmcgui.ACTION_NAV_BACK: "esc",
}


class DoToolVirtualInput(VirtualInput):
    def __init__(self) -> None:
        super().__init__()

    @property
    def id(self) -> str:
        return "dotool"

    @property
    @override
    def is_available(self) -> bool:
        if shutil.which(_DOTOOL_CMD) is None:
            return False

        result = subprocess.run([_DOTOOL_CMD], input=b"\n", check=False)

        return not result.returncode

    @override
    def send_action(self, action: int) -> None:
        key = _DOTOOL_ACTION_MAP.get(action, None)

        if key is None:
            return

        subprocess.run([_DOTOOL_CMD], input=bytes(f"key {key}\n", "ascii"), check=True)
