from abc import ABC, abstractmethod


class VirtualInput(ABC):
    @property
    @abstractmethod
    def id(self) -> str:
        pass

    @property
    @abstractmethod
    def is_available(self) -> bool:
        pass

    @abstractmethod
    def send_action(self, action: int) -> None:
        pass
