import shutil
import subprocess
from typing import override

import xbmcgui

from resources.lib.virtual_input import VirtualInput

_XDOTOOL_CMD = "xdotool"
_XDOTOOL_ACTION_MAP = {
    xbmcgui.ACTION_MOVE_LEFT: "left",
    xbmcgui.ACTION_MOVE_RIGHT: "right",
    xbmcgui.ACTION_MOVE_UP: "up",
    xbmcgui.ACTION_MOVE_DOWN: "down",
    xbmcgui.ACTION_SELECT_ITEM: "enter",
    xbmcgui.ACTION_NAV_BACK: "escape",
}


class XDoToolVirtualInput(VirtualInput):
    def __init__(self) -> None:
        super().__init__()

    @property
    def id(self) -> str:
        return "xdotool"

    @property
    @override
    def is_available(self) -> bool:
        return shutil.which(_XDOTOOL_CMD) is not None

    @override
    def send_action(self, action: int) -> None:
        key = _XDOTOOL_ACTION_MAP.get(action, None)

        if key is None:
            return

        subprocess.run([_XDOTOOL_CMD, "key", key], check=True)
