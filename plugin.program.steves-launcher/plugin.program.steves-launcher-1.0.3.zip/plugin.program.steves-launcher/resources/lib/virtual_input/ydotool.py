import shutil
import subprocess
from typing import override

import xbmcgui

from resources.lib.virtual_input import VirtualInput

_YDOTOOL_CMD = "ydotool"
_YDOTOOL_ACTION_MAP = {
    xbmcgui.ACTION_MOVE_LEFT: 105,
    xbmcgui.ACTION_MOVE_RIGHT: 106,
    xbmcgui.ACTION_MOVE_UP: 103,
    xbmcgui.ACTION_MOVE_DOWN: 108,
    xbmcgui.ACTION_SELECT_ITEM: 28,
    xbmcgui.ACTION_NAV_BACK: 1,
}


class YDoToolVirtualInput(VirtualInput):
    def __init__(self) -> None:
        super().__init__()

    @property
    def id(self) -> str:
        return "ydotool"

    @property
    @override
    def is_available(self) -> bool:
        if shutil.which(_YDOTOOL_CMD) is None:
            return False

        result = subprocess.run([_YDOTOOL_CMD, "debug"], check=False)

        return not result.returncode

    @override
    def send_action(self, action: int) -> None:
        key = _YDOTOOL_ACTION_MAP.get(action, None)

        if key is None:
            return

        subprocess.run([_YDOTOOL_CMD, "key", f"{key}:1", f"{key}:0"], check=True)
