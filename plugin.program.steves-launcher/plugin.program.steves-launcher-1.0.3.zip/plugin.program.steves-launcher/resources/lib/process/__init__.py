from abc import ABC, abstractmethod


class PendingProcess(ABC):
    @property
    @abstractmethod
    def is_active(self) -> bool:
        pass

    @property
    @abstractmethod
    def is_done(self) -> bool:
        pass

    @property
    @abstractmethod
    def is_error(self) -> bool:
        pass

    @property
    @abstractmethod
    def progress(self) -> float:
        pass

    @property
    @abstractmethod
    def status(self) -> str:
        pass

    def cancel(self) -> None:
        pass