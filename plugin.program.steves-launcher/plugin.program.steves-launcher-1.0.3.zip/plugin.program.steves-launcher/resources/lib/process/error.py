
from resources.lib.process import PendingProcess


class ErrorProcess(PendingProcess):
    def __init__(self, status: str) -> None:
        super().__init__()

        self._status = status

    @property
    def is_active(self) -> bool:
        return False

    @property
    def is_done(self) -> bool:
        return True

    @property
    def is_error(self) -> bool:
        return True

    @property
    def progress(self) -> float:
        return 0.0

    @property
    def status(self) -> str:
        return self._status

    def cancel(self) -> None:
        return