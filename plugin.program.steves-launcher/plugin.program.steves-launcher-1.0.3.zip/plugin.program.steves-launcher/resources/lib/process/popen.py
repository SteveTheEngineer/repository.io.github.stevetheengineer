import os
import re
import signal
import subprocess
from typing import cast

from resources.lib.process import PendingProcess


class POpenProcess(PendingProcess):
    def __init__(self, popen: subprocess.Popen) -> None:
        super().__init__()

        self._popen = popen
        self._pgid = os.getpgid(popen.pid)

        self._stdout = self._popen.stdout

        if self._stdout is not None:
            os.set_blocking(self._stdout.fileno(), False)

        self._progress = 0.0
        self._status = ""

    @property
    def is_active(self) -> bool:
        return self._popen.poll() is None

    @property
    def is_done(self) -> bool:
        return not self.is_active

    @property
    def is_error(self) -> bool:
        res = self._popen.poll()
        return res is not None and bool(res)

    def _read(self) -> None:
        if self._stdout is None:
            return

        while line := cast(bytes, self._stdout.readline()):
            self._status = line.decode()

            percentage_matches = re.findall(r"(\d+)%", self._status)

            if len(percentage_matches) > 0:
                percentage = int(percentage_matches[0])
                self._progress = percentage / 100.0

    @property
    def progress(self) -> float:
        self._read()
        return self._progress

    @property
    def status(self) -> str:
        self._read()
        return self._status

    def cancel(self) -> None:
        try:
            os.killpg(self._pgid, signal.SIGTERM)
        except ProcessLookupError:
            pass