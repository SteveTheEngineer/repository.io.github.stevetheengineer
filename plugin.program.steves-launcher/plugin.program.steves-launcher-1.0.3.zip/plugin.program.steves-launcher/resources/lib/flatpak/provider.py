import json
import shutil
import subprocess
from collections.abc import Sequence
from typing import override

import xbmc

from resources.lib.app.installable_app import InstallableApp
from resources.lib.app.provider import AppProvider
from resources.lib.flatpak import FlatpakApp
from resources.lib.flatpak.lib import FLATPAK_CMD, FlathubApp, FlatpakAppDescription
from resources.lib.process import PendingProcess
from resources.lib.process.popen import POpenProcess
from resources.lib.registry import Registry


class FlatpakAppProvider(AppProvider):
    def __init__(self, registry: Registry) -> None:
        super().__init__()

        self._registry = registry

    @property
    @override
    def id(self) -> str:
        return "flatpak"

    @property
    @override
    def name(self) -> str:
        return "Flatpak"

    @property
    @override
    def is_available(self) -> bool:
        return shutil.which(FLATPAK_CMD) is not None

    @override
    def get_all(self) -> Sequence[FlatpakApp]:
        if not self.is_available:
            return []

        result = subprocess.check_output(
            [FLATPAK_CMD, "list", "--json", "--columns", "all", "--app"]
        )

        data: list[FlatpakAppDescription] = json.loads(
            result, object_hook=lambda x: FlatpakAppDescription(**x)
        )

        return [FlatpakApp(self._registry, x) for x in data]

    @override
    def get(self, id: str) -> FlatpakApp | None:
        return next((x for x in self.get_all() if x.id == id), None)

    @property
    @override
    def can_install(self) -> bool:
        return True

    @override
    def search_installable(self, query: str) -> Sequence[InstallableApp]:
        if not self.is_available:
            return []

        result = subprocess.check_output(
            [FLATPAK_CMD, "search", "--json", "--columns", "all", query]
        )

        try:
            data: list[FlatpakAppDescription] = json.loads(
                result, object_hook=lambda x: FlathubApp(**x)
            )
        except json.JSONDecodeError as err:
            xbmc.log(f"Failed to find applications: {err}", xbmc.LOGWARNING)
            return []

        return [
            InstallableApp(
                id=x.application_id,
                name=x.name,
                description=x.description,
                version=x.version,
                icon_url=None,
            )
            for x in data
        ]

    @override
    def install(self, id: str) -> PendingProcess:
        popen = subprocess.Popen(
            [FLATPAK_CMD, "install", "--assumeyes", id],
            stdout=subprocess.PIPE,
            start_new_session=True,
        )
        return POpenProcess(popen)
