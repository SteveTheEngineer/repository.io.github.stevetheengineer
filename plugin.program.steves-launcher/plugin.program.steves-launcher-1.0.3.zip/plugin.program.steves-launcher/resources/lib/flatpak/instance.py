import os
import signal
import subprocess
from typing import override

from resources.lib.app.instance import AppInstance
from resources.lib.flatpak.lib import (
    FLATPAK_CMD,
    FlatpakAppDescription,
)
from resources.lib.registry import Registry


class FlatpakAppInstance(AppInstance):
    def __init__(
        self, registry: Registry, description: FlatpakAppDescription
    ) -> None:
        super().__init__()

        self._description = description
        self._process: subprocess.Popen | None = None
        self._pgid: int | None = None

        self._input = registry.virtual_input
        self._audio = registry.audio_service

    @override
    def start(self) -> None:
        self._process = subprocess.Popen(
            [FLATPAK_CMD, "run", self._description.application_id],
            start_new_session=True,
        )

        assert self._process is not None
        self._pgid = os.getpgid(self._process.pid)

    @override
    def stop(self) -> None:
        if not self._pgid or not self._process:
            return

        try:
            os.killpg(self._pgid, signal.SIGTERM)
        except ProcessLookupError:
            pass

        self._process = None
        self._pgid = None

    @override
    def poll(self) -> int | None:
        if not self._process:
            return

        return self._process.poll()

    @override
    def send_action(self, action: int) -> None:
        if self._input is None:
            return

        self._input.send_action(action)

    @property
    @override
    def is_audio_available(self) -> bool:
        return self._audio is not None

    @property
    @override
    def is_audio_initialized(self) -> bool:
        if self._audio is None:
            return False

        return (
            self._audio.get_flatpak_sink_input(self._description.application_id)
            is not None
        )

    @override
    def set_audio_sink(self, sink: str) -> None:
        if self._audio is None:
            return

        sink_input = self._audio.get_flatpak_sink_input(
            self._description.application_id
        )

        if sink_input is None:
            return

        sink_input.set_sink(sink)

        return

    @override
    def set_audio_volume(self, volume: float) -> None:
        if self._audio is None:
            return

        sink_input = self._audio.get_flatpak_sink_input(
            self._description.application_id
        )

        if sink_input is None:
            return

        sink_input.set_volume(volume)

        return
