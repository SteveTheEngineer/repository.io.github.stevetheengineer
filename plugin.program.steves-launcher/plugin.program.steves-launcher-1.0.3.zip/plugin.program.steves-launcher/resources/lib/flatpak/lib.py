from dataclasses import dataclass

FLATPAK_CMD = "flatpak"


@dataclass
class FlatpakAppDescription:
    name: str
    description: str
    application_id: str
    version: str
    branch: str
    arch: str
    origin: str
    installation: str
    ref: str
    active_commit: str
    latest_commit: str
    installed_size: str
    options: str


@dataclass
class FlathubApp:
    name: str
    description: str
    application_id: str
    version: str
    branch: str
    remotes: str    
