import glob
import pathlib
import subprocess
from typing import override

from resources.lib.app import App
from resources.lib.flatpak.instance import FlatpakAppInstance
from resources.lib.flatpak.lib import FLATPAK_CMD, FlatpakAppDescription
from resources.lib.process.popen import POpenProcess
from resources.lib.registry import Registry


class FlatpakApp(App):
    def __init__(self, registry: Registry, description: FlatpakAppDescription) -> None:
        super().__init__()

        self._registry = registry
        self._description = description

    @property
    @override
    def id(self) -> str:
        return self._description.application_id

    @property
    @override
    def provider_id(self) -> str:
        return "flatpak"

    @property
    @override
    def name(self) -> str:
        return self._description.name

    @property
    @override
    def description(self) -> str:
        return self._description.description

    @property
    @override
    def version(self) -> str:
        return self._description.version

    @property
    @override
    def icon_path(self) -> pathlib.Path | None:
        result = glob.glob(
            f"/var/lib/flatpak/app/{self._description.application_id}/current/active/files/share/icons/*/*/apps/*"
        )

        filtered = [x for x in result if x.endswith((".svg", ".png", ".jpg", ".jpeg"))]

        if len(filtered) <= 0:
            return

        sorted = [*filtered]

        sorted.sort(key=lambda v: len(v))
        sorted.reverse()

        return pathlib.Path(sorted[0])

    @override
    def create_instance(self) -> FlatpakAppInstance:
        return FlatpakAppInstance(self._registry, self._description)

    @property
    @override
    def can_uninstall(self) -> bool:
        return True

    @override
    def uninstall(self) -> POpenProcess:
        popen = subprocess.Popen(
            [
                FLATPAK_CMD,
                "uninstall",
                "--app",
                "--assumeyes",
                "--noninteractive",
                self._description.application_id,
            ],
        )

        return POpenProcess(popen)
