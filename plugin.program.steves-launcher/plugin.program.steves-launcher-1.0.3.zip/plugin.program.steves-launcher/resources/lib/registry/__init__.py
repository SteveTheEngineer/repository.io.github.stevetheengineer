from abc import ABC, abstractmethod
from collections.abc import Sequence

from resources.lib.app import App
from resources.lib.app.provider import AppProvider
from resources.lib.audio import AudioService
from resources.lib.virtual_input import VirtualInput


class Registry(ABC):
    @property
    @abstractmethod
    def all_app_providers(self) -> Sequence[AppProvider]:
        pass

    @property
    @abstractmethod
    def all_virtual_inputs(self) -> Sequence[VirtualInput]:
        pass

    @property
    @abstractmethod
    def all_audio_services(self) -> Sequence[AudioService]:
        pass

    @property
    @abstractmethod
    def app_providers(self) -> Sequence[AppProvider]:
        pass

    @abstractmethod
    def get_app_provider(self, id: str) -> AppProvider | None:
        pass

    @property
    @abstractmethod
    def apps(self) -> Sequence[App]:
        pass

    @property
    @abstractmethod
    def virtual_input(self) -> VirtualInput | None:
        pass

    @property
    @abstractmethod
    def audio_service(self) -> AudioService | None:
        pass
