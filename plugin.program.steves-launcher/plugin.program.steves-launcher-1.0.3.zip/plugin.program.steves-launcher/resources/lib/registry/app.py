import itertools
from collections.abc import Sequence

from resources.lib.app import App
from resources.lib.app.provider import AppProvider
from resources.lib.audio import AudioService
from resources.lib.audio.pipewire import PipeWireAudioService
from resources.lib.flatpak.provider import FlatpakAppProvider
from resources.lib.registry import Registry
from resources.lib.util.settings import AppSettings
from resources.lib.virtual_input import VirtualInput
from resources.lib.virtual_input.dotool import DoToolVirtualInput
from resources.lib.virtual_input.xdotool import XDoToolVirtualInput
from resources.lib.virtual_input.ydotool import YDoToolVirtualInput


class AppRegistry(Registry):
    def __init__(self, settings: AppSettings) -> None:
        self._settings = settings

    @property
    def all_app_providers(self) -> Sequence[AppProvider]:
        return [FlatpakAppProvider(self)]

    @property
    def all_virtual_inputs(self) -> Sequence[VirtualInput]:
        return [DoToolVirtualInput(), YDoToolVirtualInput(), XDoToolVirtualInput()]

    @property
    def all_audio_services(self) -> Sequence[AudioService]:
        return [PipeWireAudioService()]

    @property
    def app_providers(self) -> Sequence[AppProvider]:
        enabled_providers = [
            x for x in self.all_app_providers if self._settings.is_enabled(x.id)
        ]

        available_providers = [x for x in enabled_providers if x.is_available]

        return available_providers

    def get_app_provider(self, id: str) -> AppProvider | None:
        return next((x for x in self.app_providers if x.id == id), None)

    @property
    def apps(self) -> Sequence[App]:
        providers = self.app_providers
        chain = itertools.chain.from_iterable(x.get_all() for x in providers)
        return list(chain)

    @property
    def virtual_input(self) -> VirtualInput | None:
        enabled_inputs = [
            x for x in self.all_virtual_inputs if self._settings.is_enabled(x.id)
        ]

        return next((x for x in enabled_inputs if x.is_available), None)

    @property
    def audio_service(self) -> AudioService | None:
        enabled_services = [
            x for x in self.all_audio_services if self._settings.is_enabled(x.id)
        ]

        return next((x for x in enabled_services if x.is_available), None)
