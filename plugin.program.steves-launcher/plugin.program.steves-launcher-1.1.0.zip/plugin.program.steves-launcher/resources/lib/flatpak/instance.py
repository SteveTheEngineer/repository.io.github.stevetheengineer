import os
import signal
import subprocess
import uuid
from typing import override

from resources.lib.app.instance import AppInstance
from resources.lib.audio import SinkInput, SinkInputCriteria
from resources.lib.audio.pipewire import PIPEWIRE_TAG_PROP
from resources.lib.flatpak.lib import (
    FLATPAK_CMD,
    FlatpakAppDescription,
)
from resources.lib.registry import Registry


class FlatpakAppInstance(AppInstance):
    def __init__(self, registry: Registry, description: FlatpakAppDescription) -> None:
        super().__init__()

        self._description = description
        self._process: subprocess.Popen | None = None
        self._pgid: int | None = None

        self._input = registry.virtual_input
        self._audio = registry.audio_service

        self._audio_tag = str(uuid.uuid4())

    @override
    def start(self) -> None:
        tag_env = f"{PIPEWIRE_TAG_PROP}={self._audio_tag}"

        env = {
            "PULSE_PROP": tag_env,
            "PIPEWIRE_PROPS": tag_env,
        }

        self._process = subprocess.Popen(
            [
                FLATPAK_CMD,
                "run",
                *[f"--env={k}={v}" for k, v in env.items()],
                self._description.application_id,
            ],
            env=env,
            start_new_session=True,
        )

        assert self._process is not None
        self._pgid = os.getpgid(self._process.pid)

    @override
    def stop(self) -> None:
        if not self._pgid or not self._process:
            return

        try:
            os.killpg(self._pgid, signal.SIGTERM)
        except ProcessLookupError:
            pass

        self._process = None
        self._pgid = None

    @override
    def poll(self) -> int | None:
        if not self._process:
            return

        return self._process.poll()

    @override
    def send_action(self, action: int) -> None:
        if self._input is None:
            return

        self._input.send_action(action)

    def _find_sink_input(self) -> SinkInput | None:
        if self._audio is None:
            return

        return self._audio.find_sink_input(
            SinkInputCriteria(
                app_id=self._description.application_id,
                tag=self._audio_tag,
            )
        )

    @property
    @override
    def is_audio_available(self) -> bool:
        return self._audio is not None

    @property
    @override
    def is_audio_initialized(self) -> bool:
        return self._find_sink_input() is not None

    @override
    def set_audio_sink(self, sink: str) -> None:
        sink_input = self._find_sink_input()

        if sink_input is None:
            return

        sink_input.set_sink(sink)

    @override
    def set_audio_volume(self, volume: float) -> None:
        sink_input = self._find_sink_input()

        if sink_input is None:
            return

        sink_input.set_volume(volume)
