import json
import shutil
import subprocess
from functools import cached_property
from typing import override

from resources.lib.audio import AudioService, SinkInput, SinkInputCriteria

_WPCTL_CMD = "wpctl"
_PW_DUMP_CMD = "pw-dump"
_PW_METADATA_CMD = "pw-metadata"


PIPEWIRE_TAG_PROP = "io.github.stevetheengineer.applications.tag"


class PipeWireSinkInput(SinkInput):
    def __init__(self, id: int) -> None:
        super().__init__()

        self._id = id

    @override
    def set_sink(self, sink: str) -> None:
        subprocess.run(
            [_PW_METADATA_CMD, str(self._id), "target.object", sink], check=True
        )

    @override
    def set_volume(self, volume: float) -> None:
        subprocess.run(
            [
                _WPCTL_CMD,
                "set-volume",
                str(self._id),
                f"{volume * 100.0}%",
            ],
            check=True,
        )


class PipeWireAudioService(AudioService):
    @property
    def id(self) -> str:
        return "pipewire"

    @cached_property
    @override
    def is_available(self) -> bool:
        if shutil.which(_WPCTL_CMD) is None:
            return False

        if shutil.which(_PW_DUMP_CMD) is None:
            return False

        if shutil.which(_PW_METADATA_CMD) is None:
            return False

        result = subprocess.call([_WPCTL_CMD, "status"])

        return not result

    @override
    def find_sink_input(self, criteria: SinkInputCriteria) -> SinkInput | None:
        dump_str = subprocess.check_output([_PW_DUMP_CMD, "--no-colors", "--raw"])
        dump = json.loads(dump_str)

        for obj in dump:
            id = obj["id"]
            type = obj["type"]
            info = obj.get("info", {})
            props = info.get("props", {})

            if type != "PipeWire:Interface:Node":
                continue

            app_id = props.get("pipewire.access.portal.app_id", "")
            tag = props.get(PIPEWIRE_TAG_PROP, "")

            if app_id == criteria.app_id:
                return PipeWireSinkInput(id)

            if tag == criteria.tag:
                return PipeWireSinkInput(id)
